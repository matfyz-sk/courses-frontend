export const submissions = [
  {id:0,title:'Assignment 1',active:false, deadline:1547109900, body:'CCC this will be full body of assignment',description:'Short description of assignment' },
  {id:1,title:'Assignment 2',active:true, deadline:1549788300, body:'BBB this will be full body of assignment', description:'Short description of assignment'},
  {id:2,title:'Assignment 3',active:false, deadline:1547109900, body:'CCC this will be full body of assignment',description:'Short description of assignment' },
  {id:3,title:'Assignment 4',active:true, deadline:1549788300, body:'BBB this will be full body of assignment', description:'Short description of assignment'},
]

export const teams = [
  {value:0,label:'Jarovice',members:[{id:1,name:'Jaroslav',surname:'Matejovic'},{id:2,name:'Jaroslav',surname:'Biely'},{id:0,name:'Juraj',surname:'Macek'}]},
  {value:1,label:'Failures',members:[{id:4,name:'Barbora',surname:'Severna'},{id:5,name:'Martin',surname:'Juzny'},{id:0,name:'Juraj',surname:'Macek'}]}
]
